import numpy as np
import pandas as pd
import pywt
import neurokit2 as nk
import tensorflow as tf
from keras.models import load_model
from sklearn.preprocessing import LabelEncoder
from keras.utils import to_categorical

modelPath = r"c:\Users\alexl\Desktop\best_model.h5"
testDataPath = r"c:\Users\alexl\Desktop\start-up\Testing\Data\prepared\3p_1p\verify_1p.xlsx"

# Load the trained model
model = load_model(modelPath)

# Function to extract data from Excel file
def extract_columns_as_arrays(file_path):
    df = pd.read_excel(file_path)
    columns_data = {col: df[col].dropna().tolist() for col in df.columns}
    return columns_data

# Generate scalogram for each column in the CSV file (Adjust sampling_rate and sampling_time as required)
def generate_scalograms(data_dict, sampling_rate=1500):
    wavelet = 'morl'
    sampling_period = 1 / sampling_rate
    min_frequency = 20  # Minimum frequency of interest (e.g., 20 Hz)
    max_frequency = 748  # Maximum frequency of interest (e.g., 498 Hz)
    min_scale = pywt.central_frequency(wavelet) / (max_frequency * sampling_period)
    max_scale = pywt.central_frequency(wavelet) / (min_frequency * sampling_period)
    scales = np.arange(min_scale, max_scale, step=1)  # Adjust step size as needed

    scalograms = []
    column_names = []

    for column_name, data_array in data_dict.items():
        if len(data_array) == 0:
            continue  # Skip empty columns

        # Processing signal using neurokit2
        emg_cleaned = nk.emg_clean(data_array, sampling_rate=sampling_rate, method='biosppy')

        # Perform the Continuous Wavelet Transform using pywt
        coefs, freqs = pywt.cwt(emg_cleaned, scales, wavelet, sampling_period=sampling_period)

        # Store scalogram data and column name
        scalograms.append(coefs)
        column_names.append(column_name)

    return scalograms, column_names

# Function to normalize and resize scalograms
def prepare_scalograms(scalograms):
    
    # Temporary hard number coding due to sensor sampling rate issues
    max_length = 15000
    prepared_scalograms = []

    for scalogram in scalograms:
      # Adjust the scalogram sample number
      if scalogram.shape[1] > max_length:
        scalogram_adjusted = scalogram[:, :max_length]
      elif scalogram.shape[1] < max_length:
        padding = np.zeros((scalogram.shape[0], max_length - scalogram.shape[1]))
        scalogram_adjusted = np.hstack((scalogram, padding))
      else:
        scalogram_adjusted = scalogram

      # Normalize the scalogram
      min_val = np.min(scalogram_adjusted)
      max_val = np.max(scalogram_adjusted)
      scalogram_normalized = scalogram_adjusted / (max_val - min_val)

      prepared_scalograms.append(scalogram_normalized)

    # Convert list to numpy array
    prepared_scalograms = np.array(prepared_scalograms)

    # Reshape to (number of samples, height, width, channels)
    scalograms_reshaped = prepared_scalograms.reshape((len(prepared_scalograms), prepared_scalograms[0].shape[0], max_length, 1))

    return scalograms_reshaped

# File path to the new data
new_file_path = testDataPath

# Extract, process and prepare the new data
new_data_dict = extract_columns_as_arrays(new_file_path)
new_scalograms, new_column_names = generate_scalograms(new_data_dict)
prepared_new_scalograms = prepare_scalograms(new_scalograms)

# Generate labels for new data (same format as used for training data)
labels_dict = {column_name: 0 if 'negative' in column_name else 1 for column_name in new_column_names}
new_labels = np.array([labels_dict[column_name] for column_name in new_column_names])

# Predict with the model
predictions = model.predict(prepared_new_scalograms)

# Evaluate the model on the new data
new_loss, new_accuracy = model.evaluate(prepared_new_scalograms, new_labels)
print(f"New data accuracy: {new_accuracy}")

# Optionally, convert predictions to class labels
predicted_labels = (predictions > 0.5).astype(int)

# Print some example predictions
for i, col_name in enumerate(new_column_names):
    print(f"Sample {col_name}: True label = {new_labels[i]}, Predicted label = {predicted_labels[i][0]}")
