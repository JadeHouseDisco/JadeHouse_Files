import numpy as np
import pandas as pd
import pywt
import neurokit2 as nk
import matplotlib.pyplot as plt
import tensorflow as tf
import keras_tuner as kt
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Conv2D, BatchNormalization, MaxPooling2D, Flatten, Dense, Dropout, GlobalAveragePooling2D
from keras.utils import to_categorical
from keras.optimizers import Adam, RMSprop
from keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from keras.regularizers import l2
from tensorflow.keras import mixed_precision
policy = mixed_precision.Policy('mixed_float16')
mixed_precision.set_global_policy(policy)
import os
os.environ['TF_GPU_ALLOCATOR'] = 'cuda_malloc_async'

samplingRate = 1500
samplingTime = 10
tuneEpoch = 50
trainEpoch = 5000
tuneDataFilePath = r"c:\Users\alexl\Desktop\SENSE\Testing\Data\prepared\2p_1p\muscle_data_tune_2p.xlsx"
trainDataFilePath = r"c:\Users\alexl\Desktop\SENSE\Testing\Data\prepared\2p_1p\muscle_data_2p.xlsx"

# Function to extract data from Excel file
def extract_columns_as_arrays(file_path):
    df = pd.read_excel(file_path)
    columns_data = {col: df[col].dropna().tolist() for col in df.columns}
    return columns_data

# Generate scalogram for each column in the CSV file (Adjust sampling_rate and sampling_time as required)
def generate_scalograms(data_dict, sampling_rate=samplingRate):
    wavelet = 'morl'
    sampling_period = 1 / sampling_rate
    min_frequency = 20  # Minimum frequency of interest (e.g., 20 Hz)
    max_frequency = 748  # Maximum frequency of interest (e.g., 498 Hz)
    min_scale = pywt.central_frequency(wavelet) / (max_frequency * sampling_period)
    max_scale = pywt.central_frequency(wavelet) / (min_frequency * sampling_period)
    scales = np.arange(min_scale, max_scale, step=1)  # Adjust step size as needed

    scalograms = []
    column_names = []

    for column_name, data_array in data_dict.items():
        if len(data_array) == 0:
            continue
        
        emg_cleaned = nk.emg_clean(data_array, sampling_rate=sampling_rate, method='biosppy')

        # Perform the Continuous Wavelet Transform using pywt
        coefs, freqs = pywt.cwt(emg_cleaned, scales, wavelet, sampling_period=sampling_period)

        # Store scalogram data and column name
        scalograms.append(coefs)
        column_names.append(column_name)

    return scalograms, column_names

# Function to normalize and resize scalograms
def prepare_scalograms(scalograms, sampling_rate=samplingRate, sampling_time=samplingTime):
    
    # Temporary hard number coding due to sensor sampling rate issues
    max_length = sampling_rate * sampling_time
    prepared_scalograms = []

    for scalogram in scalograms:
      # Adjust the scalogram sample number
      if scalogram.shape[1] > max_length:
        scalogram_adjusted = scalogram[:, :max_length]
      elif scalogram.shape[1] < max_length:
        padding = np.zeros((scalogram.shape[0], max_length - scalogram.shape[1]))
        scalogram_adjusted = np.hstack((scalogram, padding))
      else:
        scalogram_adjusted = scalogram

      # Normalize the scalogram
      min_val = np.min(scalogram_adjusted)
      max_val = np.max(scalogram_adjusted)
      scalogram_normalized = scalogram_adjusted / (max_val - min_val)

      prepared_scalograms.append(scalogram_normalized)

    # Convert list to numpy array
    prepared_scalograms = np.array(prepared_scalograms)

    # Reshape to (number of samples, height, width, channels)
    scalograms_reshaped = prepared_scalograms.reshape((len(prepared_scalograms), prepared_scalograms[0].shape[0], max_length, 1))

    return scalograms_reshaped

'''
def find_optimal_tune_batch_size(tuner, X_train, y_train, max_batch_size=64, min_batch_size=1):
    current_batch_size = max_batch_size
    
    while current_batch_size >= min_batch_size:
        try:
            tuner.search(X_train, y_train, epochs=1, batch_size=current_batch_size, validation_data=(X_test, y_test))
            print(f"Successfully found optimal batch size: {current_batch_size}")
            return current_batch_size
        except tf.errors.ResourceExhaustedError:
            print(f"Batch size {current_batch_size} too large, trying smaller size.")
            current_batch_size = max(current_batch_size // 2, min_batch_size)
    
    print(f"Could not find a suitable batch size. Using minimum batch size: {min_batch_size}")
    return min_batch_size

def find_optimal_train_batch_size(model, X_train, y_train, max_batch_size=64, min_batch_size=1):
    current_batch_size = max_batch_size
    
    while current_batch_size >= min_batch_size:
        try:
            model.fit(X_train, y_train, batch_size=current_batch_size, epochs=1, verbose=0)
            print(f"Successfully found optimal batch size: {current_batch_size}")
            return current_batch_size
        except tf.errors.ResourceExhaustedError:
            print(f"Batch size {current_batch_size} too large, trying smaller size.")
            current_batch_size = max(current_batch_size // 2, min_batch_size)
    
    print(f"Could not find a suitable batch size. Using minimum batch size: {min_batch_size}")
    return min_batch_size
'''

# Main code to read data, generate scalograms, and prepare for CNN
file_path = tuneDataFilePath
data_dict = extract_columns_as_arrays(file_path)
scalograms, column_names = generate_scalograms(data_dict)
prepared_scalograms = prepare_scalograms(scalograms)

# Create labels (column name must be in the format negative # or positive #)
labels_dict = {column_name: 0 if 'negative' in column_name else 1 for column_name in column_names}
labels = np.array([labels_dict[column_name] for column_name in column_names])

# Train test split
X_train, X_test, y_train, y_test = train_test_split(prepared_scalograms, labels, test_size=0.2)

# Define input shape
input_shape = (prepared_scalograms[0].shape)

# Build the CNN model
model = Sequential()

# Define a HyperModel
def build_model(hp):
    model = Sequential()

    # First convolutional block
    model.add(Conv2D(
        filters=hp.Int('conv_1_filter', min_value=32, max_value=128, step=16),
        kernel_size=hp.Choice('conv_1_kernel', values=[3, 5, 7]),
        activation='relu',
        kernel_initializer='he_uniform',
        padding='same',
        input_shape=input_shape
    ))
    model.add(BatchNormalization())
    model.add(MaxPooling2D((2, 2)))

    # Second convolutional block
    model.add(Conv2D(
        filters=hp.Int('conv_2_filter', min_value=64, max_value=256, step=32),
        kernel_size=hp.Choice('conv_2_kernel', values=[3, 5, 7]),
        activation='relu',
        kernel_initializer='he_uniform',
        padding='same'
    ))
    model.add(BatchNormalization())
    model.add(MaxPooling2D((2, 2)))

    # Third convolutional block
    model.add(Conv2D(
        filters=hp.Int('conv_3_filter', min_value=128, max_value=512, step=64),
        kernel_size=hp.Choice('conv_3_kernel', values=[3, 5, 7]),
        activation='relu',
        kernel_initializer='he_uniform',
        padding='same'
    ))
    model.add(BatchNormalization())
    model.add(MaxPooling2D((2, 2)))

    # Fourth convolutional block
    model.add(Conv2D(
        filters=hp.Int('conv_4_filter', min_value=128, max_value=512, step=64),
        kernel_size=hp.Choice('conv_4_kernel', values=[3, 5, 7]),
        activation='relu',
        kernel_initializer='he_uniform',
        padding='same'
    ))
    model.add(BatchNormalization())
    model.add(MaxPooling2D((2, 2)))

    # Global Average Pooling
    model.add(GlobalAveragePooling2D())

    # Dense layers
    model.add(Dense(
        units=hp.Int('dense_units', min_value=128, max_value=512, step=64),
        activation='relu',
        kernel_regularizer=l2(0.001)
    ))
    model.add(Dropout(0.5))
    model.add(Dense(1, activation='sigmoid'))

    # Compile the model
    model.compile(
        optimizer=Adam(hp.Choice('learning_rate', values=[1e-2, 1e-3, 1e-4])),
        loss='binary_crossentropy',
        metrics=['accuracy']
    )

    return model

# Instantiate the tuner (try BayesianOptimization and Hyperband)
tuner = kt.RandomSearch(
    build_model,
    objective='val_accuracy',
    max_trials=20,
    executions_per_trial=2,
    directory=r'C:\Users\alexl\Desktop\tuner_search_results',
    project_name='scalogram_sEMG_tuning'
)

# Define callbacks
early_stopping = EarlyStopping(monitor='val_accuracy', patience=25, restore_best_weights=True)
model_checkpoint = ModelCheckpoint('best_model.h5', save_best_only=True, monitor='val_loss')
reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=5, min_lr=0.00001)

'''
# Find the optimal batch size for training
optimal_tune_batch_size = find_optimal_tune_batch_size(tuner, X_train, y_train)
print(f"Optimal batch size for tuning: {optimal_tune_batch_size}")
'''

# Perform the hyperparameter search
tuner.search(X_train, y_train, epochs=tuneEpoch, batch_size=1, validation_data=(X_test, y_test))

# Get the optimal hyperparameters
best_hps = tuner.get_best_hyperparameters(num_trials=1)[0]

# Print the optimal hyperparameters
print(f"""
The optimal number of filters in the first convolutional layer is {best_hps.get('conv_1_filter')}.
The optimal kernel size for the first convolutional layer is {best_hps.get('conv_1_kernel')}.
The optimal number of filters in the second convolutional layer is {best_hps.get('conv_2_filter')}.
The optimal kernel size for the second convolutional layer is {best_hps.get('conv_2_kernel')}.
The optimal number of filters in the third convolutional layer is {best_hps.get('conv_3_filter')}.
The optimal kernel size for the third convolutional layer is {best_hps.get('conv_3_kernel')}.
The optimal number of filters in the fourth convolutional layer is {best_hps.get('conv_4_filter')}.
The optimal kernel size for the fourth convolutional layer is {best_hps.get('conv_4_kernel')}.
The optimal number of units in the dense layer is {best_hps.get('dense_units')}.
The optimal learning rate for the optimizer is {best_hps.get('learning_rate')}.
""")

# Build the model with the optimal hyperparameters
model = tuner.hypermodel.build(best_hps)

# Full data for training the model
file_path = trainDataFilePath
data_dict = extract_columns_as_arrays(file_path)
scalograms, column_names = generate_scalograms(data_dict)
prepared_scalograms = prepare_scalograms(scalograms)

# Create labels (column name must be in the format negative # or positive #)
labels_dict = {column_name: 0 if 'negative' in column_name else 1 for column_name in column_names}
labels = np.array([labels_dict[column_name] for column_name in column_names])

# Train test split
X_train, X_test, y_train, y_test = train_test_split(prepared_scalograms, labels, test_size=0.2)

tf.keras.backend.clear_session()

'''
# Find the optimal batch size for training
optimal_train_batch_size = find_optimal_train_batch_size(model, X_train, y_train)
print(f"Optimal batch size for training: {optimal_train_batch_size}")
'''

# Train the model with the optimal hyperparameters
history = model.fit(X_train, y_train, epochs=trainEpoch, batch_size=1, validation_data=(X_test, y_test), callbacks=[model_checkpoint, reduce_lr])

tf.keras.backend.clear_session()

# Evaluate the model on the test set
test_loss, test_accuracy = model.evaluate(X_test, y_test, batch_size=1)
print(f"Test accuracy: {test_accuracy}")

# Plot training & validation accuracy values
plt.figure(figsize=(12, 4))
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('Model accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend(['Train', 'Test'], loc='upper left')

# Plot training & validation loss values
plt.subplot(1, 2, 2)
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('Model loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend(['Train', 'Test'], loc='upper left')

plt.show()

# Save the model
model.save("sEMG_model.h5")