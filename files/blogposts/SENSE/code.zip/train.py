import numpy as np
import pandas as pd
import pywt
import neurokit2 as nk
import matplotlib.pyplot as plt
import tensorflow as tf
import keras_tuner as kt
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Conv2D, BatchNormalization, MaxPooling2D, Flatten, Dense, Dropout
from keras.optimizers import Adam, RMSprop
from keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from keras.regularizers import l2

# Function to extract data from Excel file
def extract_columns_as_arrays(file_path):
    df = pd.read_excel(file_path)
    columns_data = {col: df[col].dropna().tolist() for col in df.columns}
    return columns_data

# Generate scalogram for each column in the CSV file (Adjust sampling_rate and sampling_time as required)
def generate_scalograms(data_dict, sampling_rate=1250):
    wavelet = 'morl'
    sampling_period = 1 / sampling_rate
    min_frequency = 20  # Minimum frequency of interest (e.g., 20 Hz)
    max_frequency = 498  # Maximum frequency of interest (e.g., 498 Hz)
    min_scale = pywt.central_frequency(wavelet) / (max_frequency * sampling_period)
    max_scale = pywt.central_frequency(wavelet) / (min_frequency * sampling_period)
    scales = np.arange(min_scale, max_scale, step=1)  # Adjust step size as needed

    scalograms = []
    column_names = []

    for column_name, data_array in data_dict.items():
        if len(data_array) == 0:
            continue  # Skip empty columns

        # Processing signal using neurokit2
        # signals, info = nk.emg_process(data_array, sampling_rate=sampling_rate)
        # emg_cleaned = signals['EMG_Clean'].values
        emg_cleaned = nk.emg_clean(data_array, sampling_rate=sampling_rate, method='biosppy')

        # Perform the Continuous Wavelet Transform using pywt
        coefs, freqs = pywt.cwt(emg_cleaned, scales, wavelet, sampling_period=sampling_period)

        # This line is very weird (Check why there is negative number from emg_cleaned)
        # scalogram = np.abs(coefs)

        # Store scalogram data and column name
        scalograms.append(coefs)
        column_names.append(column_name)

    return scalograms, column_names

# Function to normalize and resize scalograms
def prepare_scalograms(scalograms, sampling_rate=1250, sampling_time=10):
    
    # Temporary hard number coding due to sensor sampling rate issues
    max_length = sampling_rate * sampling_time
    prepared_scalograms = []

    for scalogram in scalograms:
      # Adjust the scalogram sample number
      if scalogram.shape[1] > max_length:
        scalogram_adjusted = scalogram[:, :max_length]
      elif scalogram.shape[1] < max_length:
        padding = np.zeros((scalogram.shape[0], max_length - scalogram.shape[1]))
        scalogram_adjusted = np.hstack((scalogram, padding))
      else:
        scalogram_adjusted = scalogram

      # Normalize the scalogram
      min_val = np.min(scalogram_adjusted)
      max_val = np.max(scalogram_adjusted)
      scalogram_normalized = scalogram_adjusted / (max_val - min_val)

      prepared_scalograms.append(scalogram_normalized)

    # Convert list to numpy array
    prepared_scalograms = np.array(prepared_scalograms)

    # Reshape to (number of samples, height, width, channels)
    scalograms_reshaped = prepared_scalograms.reshape((len(prepared_scalograms), prepared_scalograms[0].shape[0], max_length, 1))

    return scalograms_reshaped

def find_optimal_batch_size(model, X_train, y_train, max_batch_size=64, min_batch_size=1):
    current_batch_size = max_batch_size
    
    while current_batch_size >= min_batch_size:
        try:
            model.fit(X_train, y_train, batch_size=current_batch_size, epochs=1, verbose=0)
            print(f"Successfully found optimal batch size: {current_batch_size}")
            return current_batch_size
        except tf.errors.ResourceExhaustedError:
            print(f"Batch size {current_batch_size} too large, trying smaller size.")
            current_batch_size = max(current_batch_size // 2, min_batch_size)
    
    print(f"Could not find a suitable batch size. Using minimum batch size: {min_batch_size}")
    return min_batch_size

# Main code to read data, generate scalograms, and prepare for CNN
file_path = r'c:\Users\alexl\Desktop\start-up\Testing\Data\muscle_data_3p.xlsx'
data_dict = extract_columns_as_arrays(file_path)
scalograms, column_names = generate_scalograms(data_dict)
prepared_scalograms = prepare_scalograms(scalograms)

# Create labels (column name must be in the format negative # or positive #)
labels_dict = {column_name: 0 if 'negative' in column_name else 1 for column_name in column_names}
labels = np.array([labels_dict[column_name] for column_name in column_names])

# Train test split
X_train, X_test, y_train, y_test = train_test_split(prepared_scalograms, labels, test_size=0.2)

# Define input shape
input_shape = (prepared_scalograms[0].shape)

# Build the CNN model
model = Sequential()

# First convolutional block
model.add(Conv2D(16, (5, 5), activation='relu', kernel_initializer='he_uniform', input_shape=input_shape))
model.add(BatchNormalization())
model.add(MaxPooling2D((2, 2)))

# Second convolutional block
model.add(Conv2D(32, (3, 3), activation='relu', kernel_initializer='he_uniform'))
model.add(BatchNormalization())
model.add(MaxPooling2D((2, 2)))

# Third convolutional block
model.add(Conv2D(64, (3, 3), activation='relu', kernel_initializer='he_uniform'))
model.add(BatchNormalization())
model.add(MaxPooling2D((2, 2)))

# Fourth convolutional block
model.add(Conv2D(128, (3, 3), activation='relu', kernel_initializer='he_uniform'))
model.add(BatchNormalization())
model.add(MaxPooling2D((2, 2)))

# Fully connected layer
model.add(Flatten())
model.add(Dense(128, activation='relu', kernel_regularizer=l2(0.001)))
model.add(Dropout(0.5))
model.add(Dense(1, activation='sigmoid'))

# Compile the model
model.compile(optimizer=Adam(learning_rate=0.001), loss='binary_crossentropy', metrics=['accuracy'])

'''
# Callbacks for early stopping, model checkpoint, and learning rate reduction
early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
model_checkpoint = ModelCheckpoint('best_model.h5', save_best_only=True, monitor='val_loss')
reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=5, min_lr=0.00001)

# Train the model (add these callbacks to your fit function)
history = model.fit(X_train, y_train, epochs=300, batch_size=32, validation_data=(X_test, y_test),
                    callbacks=[early_stopping, model_checkpoint, reduce_lr])
'''

# Find the optimal batch size for training
optimal_batch_size = find_optimal_batch_size(model, X_train, y_train)
print(f"Optimal batch size for training: {optimal_batch_size}")

early_stopping = EarlyStopping(monitor='val_accuracy', patience=50, restore_best_weights=True)
model_checkpoint = ModelCheckpoint('best_model.h5', save_best_only=True, monitor='val_loss')
reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=5, min_lr=0.00001)

# Train the model (add these callbacks to your fit function)
history = model.fit(X_train, y_train, epochs=5000, batch_size=optimal_batch_size, validation_data=(X_test, y_test), callbacks=[model_checkpoint, reduce_lr])

# Evaluate the model on the test set
test_loss, test_accuracy = model.evaluate(X_test, y_test)
print(f"Test accuracy: {test_accuracy}")

# Plot training & validation accuracy values
plt.figure(figsize=(12, 4))
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('Model accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend(['Train', 'Test'], loc='upper left')

# Plot training & validation loss values
plt.subplot(1, 2, 2)
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('Model loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend(['Train', 'Test'], loc='upper left')

plt.show()

# Save the model
model.save("sEMG_model.h5")